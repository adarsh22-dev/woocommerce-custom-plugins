<?php
/**
 * Plugin Name: CISAI VendorHub Inventory Manager (Stock-only) v95
 * Description: Mobile-first SKU inventory manager for multi-vendor WooCommerce. Vendor-only, stock updates + audit + scanner + CSV export. (No AI, no create/delete)
 * Version: 1.3.1
 * Author: VendorHub
 * Requires at least: 5.8
 * Requires PHP: 7.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class VendorHub_Inventory_Manager {
    const VERSION   = '1.3.1';
    const OPT_KEY   = 'vendorhub_inventory_manager_options';
    const PAGE_OPT  = 'vendorhub_inventory_manager_page_id';
    const SHORTCODE = 'vendorhub_inventory';
    const CAP       = 'manage_vendorhub_inventory';

    private static $instance = null;

    // Portal inline login state (set during template_redirect, read by shortcode renderer)
    private $portal_login_error = '';

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'init', array( $this, 'register_shortcode' ) );
        add_action( 'init', array( $this, 'maybe_schedule_self_heal' ) );

        // Handle VendorHub portal login BEFORE any output so auth cookies can be set reliably.
        add_action( 'template_redirect', array( $this, 'handle_portal_login_submit' ), 0 );

        // Prevent full-page cache from serving the guest login view to logged-in vendors.
        add_action( 'send_headers', array( $this, 'maybe_send_no_cache_headers' ), 0 );

        // Cron callback
        add_action( 'vendorhub_inventory_self_heal', array( __CLASS__, 'run_self_heal' ) );

        add_action( 'rest_api_init', array( $this, 'register_rest' ) );

        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );

        // Ensure mobile viewport is set on the portal page (some templates omit it)
        add_action( 'wp_head', array( $this, 'maybe_add_viewport_meta' ), 1 );

        add_action( 'wp_ajax_vendorhub_audit_export', array( $this, 'ajax_audit_export' ) );

        // Force login redirect back to VendorHub portal when login happens from our page
        add_filter( 'login_redirect', array( $this, 'filter_login_redirect' ), 1000, 3 );

        // Only allow vendor roles to authenticate when logging in via the VendorHub portal form.
        // Non-vendors (customers/wholesalers/etc.) should see a generic "incorrect username/password" style error.
        add_filter( 'wp_authenticate_user', array( $this, 'restrict_vendorhub_portal_login' ), 50, 2 );

        // Optional: add WCFM dashboard menu (safe even if WCFM inactive)
        add_filter( 'wcfm_menus', array( $this, 'filter_wcfm_menus' ), 90, 1 );

        // Admin settings page
        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
        add_action( 'admin_init', array( $this, 'admin_init' ) );

        add_action( 'admin_post_vendorhub_inventory_recreate_page', array( $this, 'handle_recreate_page' ) );
    }

    public static function activate() {
        self::add_caps_and_roles();
self::create_tables();
        self::maybe_create_portal_page();
        self::schedule_self_heal_event();
        flush_rewrite_rules();
    }

    
    /* ---------------------------
     * Capabilities / Roles
     * --------------------------- */
    public static function add_caps_and_roles() {
        // Add a dedicated capability so you can grant plugin access without giving full admin.
        $cap = self::CAP;

        // Ensure key roles have access by default.
        $admin = get_role( 'administrator' );
        if ( $admin && ! $admin->has_cap( $cap ) ) {
            $admin->add_cap( $cap );
        }

        $shop = get_role( 'shop_manager' );
        if ( $shop && ! $shop->has_cap( $cap ) ) {
            $shop->add_cap( $cap );
        }

        // Optional: create a minimal role for external devs.
        if ( ! get_role( 'vendorhub_developer' ) ) {
            add_role(
                'vendorhub_developer',
                'VendorHub Developer',
                array(
                    'read' => true,
                    $cap   => true,
                )
            );
        }
    }

public static function deactivate() {
        wp_clear_scheduled_hook( 'vendorhub_inventory_self_heal' );
        flush_rewrite_rules();
    }

    /* ---------------------------
     * Options
     * --------------------------- */
    public static function default_options() {
        return array(
            // Portal access is restricted to WCFM vendors by default.
            // If WCFM is not installed, the plugin will fall back to this list.
            'allowed_roles'  => 'wcfm_vendor',
            'allow_admin'    => 'no',
            'low_stock'      => 5,
            'per_page'       => 100,
            'rate_read_per_min'  => 120,
            'rate_write_per_min' => 60,
            'barcode_meta_keys'  => '_barcode,_ean,_alg_ean,_wpm_product_gtin,_ywbc_barcode,_wc_product_barcode,_gtin,_isbn,_upc',
            'require_2fa'    => 'no',
        );
    }

    public static function get_options() {
        $opts = get_option( self::OPT_KEY, array() );
        if ( ! is_array( $opts ) ) { $opts = array(); }
        return wp_parse_args( $opts, self::default_options() );
    }

    /* ---------------------------
     * Tables
     * --------------------------- */
    private static function table_audit() {
        global $wpdb;
        return $wpdb->prefix . 'vendorhub_inventory_audit';
    }

    private static function create_tables() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();
        $audit   = self::table_audit();

        $sql = "CREATE TABLE {$audit} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            vendor_id BIGINT UNSIGNED NOT NULL,
            product_id BIGINT UNSIGNED NOT NULL,
            variation_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            sku VARCHAR(191) NOT NULL DEFAULT '',
            delta INT NOT NULL,
            new_qty INT NULL,
            reason VARCHAR(50) NOT NULL DEFAULT 'manual',
            source VARCHAR(20) NOT NULL DEFAULT 'manual',
            ip VARCHAR(64) NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY vendor_time (vendor_id, created_at),
            KEY sku_time (sku, created_at)
        ) {$charset};";

        dbDelta( $sql );
    }

    /* ---------------------------
     * Page (auto create + self-heal)
     * --------------------------- */
    private static function portal_page_title() {
        return 'VendorHub Inventory';
    }

    private static function portal_shortcode_content() {
        return '[' . self::SHORTCODE . ' show_login="yes"]';
    }

    public static function maybe_create_portal_page() {
        $existing = intval( get_option( self::PAGE_OPT, 0 ) );
        if ( $existing && get_post( $existing ) ) {
            return $existing;
        }

        $page_id = wp_insert_post( array(
            'post_title'   => self::portal_page_title(),
            'post_content' => self::portal_shortcode_content(),
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ) );

        if ( ! is_wp_error( $page_id ) && $page_id ) {
            update_option( self::PAGE_OPT, intval( $page_id ) );
            return intval( $page_id );
        }

        return 0;
    }

    public function maybe_schedule_self_heal() {
        if ( is_admin() ) {
            self::schedule_self_heal_event();
        }
    }

    public static function schedule_self_heal_event() {
        if ( ! wp_next_scheduled( 'vendorhub_inventory_self_heal' ) ) {
            wp_schedule_event( time() + 3600, 'daily', 'vendorhub_inventory_self_heal' );
        }
}

    private function is_portal_page() {
        $pid = intval( get_option( self::PAGE_OPT, 0 ) );
        return ( $pid && is_page( $pid ) );
    }

    /* ---------------------------
     * Shortcode
     * --------------------------- */
    public function register_shortcode() {
        add_shortcode( self::SHORTCODE, array( $this, 'shortcode_app' ) );
    }

    public function shortcode_app( $atts ) {
        $atts = shortcode_atts( array(
            'show_login' => 'no',
        ), $atts, self::SHORTCODE );

        // If not logged in and login gate desired
        if ( ! is_user_logged_in() ) {
            if ( $atts['show_login'] === 'yes' ) {
                return $this->render_login_gate();
            }
            return '<div class="vh-denied">Please login.</div>';
        }

        if ( ! $this->user_is_allowed() ) {
            return '<div class="vh-denied">Access denied.</div>';
        }

        // 2FA gate (optional)
        $opts = self::get_options();
        if ( isset( $opts['require_2fa'] ) && $opts['require_2fa'] === 'yes' ) {
            if ( ! $this->user_has_2fa( get_current_user_id() ) ) {
                return '<div class="vh-denied">2FA required for access.</div>';
            }
        }

        // Mount point
        return '<div id="vendorhub-app"></div>';
    }


    /**
     * Process VendorHub portal login before template output.
     * This avoids "headers already sent" issues, so auth cookies persist correctly on success.
     */
    public function handle_portal_login_submit() {
        if ( 'POST' !== $_SERVER['REQUEST_METHOD'] ) { return; }
        if ( ! isset( $_POST['vh_login'] ) ) { return; }
        if ( ! $this->is_portal_page() ) { return; }

        $this->portal_login_error = '';

        $nonce = isset( $_POST['vh_nonce'] ) ? (string) wp_unslash( $_POST['vh_nonce'] ) : '';
        $ok    = $nonce && wp_verify_nonce( $nonce, 'vendorhub_portal_login' );

        $login = isset( $_POST['log'] ) ? (string) wp_unslash( $_POST['log'] ) : '';
        $pass  = isset( $_POST['pwd'] ) ? (string) wp_unslash( $_POST['pwd'] ) : '';
        $remember = ! empty( $_POST['rememberme'] );

        if ( ! $ok || $login === '' || $pass === '' ) {
            $this->portal_login_error = __( 'Incorrect username or password.' );
            return;
        }

        $creds = array(
            'user_login'    => $login,
            'user_password' => $pass,
            'remember'      => $remember,
        );

        // Sign in (sets auth cookies via headers, since we are pre-output).
        $user = wp_signon( $creds, is_ssl() );

        if ( is_wp_error( $user ) || ! $user ) {
            $this->portal_login_error = __( 'Incorrect username or password.' );
            return;
        }

        // Extra guard: even with correct creds, only vendors are allowed on this portal.
        if ( ! $this->user_is_allowed_user( $user->ID ) ) {
            wp_logout();
            $this->portal_login_error = __( 'Incorrect username or password.' );
            return;
        }

        // Ensure current user is set for the remainder of this request.
        wp_set_current_user( $user->ID );
    }

    private function render_login_gate() {
        $error_msg = (string) $this->portal_login_error;

        ob_start();
        echo '<div class="vh-login-wrap"><div class="vh-login">';
        echo '<h2>' . esc_html( $this->get_portal_title() ) . '</h2>';
        echo '<div class="vh-sub">Login to manage your stock.</div>';

        if ( $error_msg ) {
            echo '<div class="vh-error">' . esc_html( $error_msg ) . '</div>';
        }

        echo '<form name="loginform" id="vh-loginform" action="" method="post">';
        echo '<p class="login-username">';
        echo '<label for="vh_user_login">' . esc_html__( 'Username or Email' ) . '</label>';
        echo '<input type="text" name="log" id="vh_user_login" autocomplete="username" required />';
        echo '</p>';

        echo '<p class="login-password">';
        echo '<label for="vh_user_pass">' . esc_html__( 'Password' ) . '</label>';
        echo '<input type="password" name="pwd" id="vh_user_pass" autocomplete="current-password" required />';
        echo '</p>';

        echo '<p class="login-remember"><label><input name="rememberme" type="checkbox" value="forever"> ' . esc_html__( 'Remember Me' ) . '</label></p>';

        echo '<input type="hidden" name="vh_login" value="1" />';
        echo wp_nonce_field( 'vendorhub_portal_login', 'vh_nonce', true, false );

        echo '<p class="login-submit"><input type="submit" name="wp-submit" id="wp-submit" value="' . esc_attr__( 'Log In' ) . '" /></p>';
        echo '</form>';

        echo '</div></div>';
        return ob_get_clean();
    }


    private function current_url() {
        $scheme = is_ssl() ? 'https' : 'http';
        $host   = isset( $_SERVER['HTTP_HOST'] ) ? wp_unslash( $_SERVER['HTTP_HOST'] ) : '';
        $uri    = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
        $url    = $scheme . '://' . $host . $uri;
        return esc_url_raw( $url );
    }


    /**
     * Add viewport meta on the VendorHub portal page to ensure proper mobile scaling
     * even when the active theme/vendor dashboard template forgets it.
     */
    public function maybe_add_viewport_meta() {
        if ( ! $this->is_portal_page() ) {
            return;
        }
        echo '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />' . "\n";
    }


    /**
     * Disable caching for the VendorHub portal page.
     * Some cache layers can otherwise serve the guest login screen even after successful login.
     */
    public function maybe_send_no_cache_headers() {
        if ( ! $this->is_portal_page() ) {
            return;
        }

        if ( ! defined( 'DONOTCACHEPAGE' ) ) { define( 'DONOTCACHEPAGE', true ); }
        if ( ! defined( 'DONOTCACHEDB' ) ) { define( 'DONOTCACHEDB', true ); }
        if ( ! defined( 'DONOTCACHEOBJECT' ) ) { define( 'DONOTCACHEOBJECT', true ); }

        if ( function_exists( 'nocache_headers' ) ) {
            nocache_headers();
        }
    }


    /* ---------------------------
     * Enqueue assets
     * --------------------------- */
    public function enqueue_assets() {
        if ( ! is_user_logged_in() ) {
            // Still enqueue login CSS (outside shadow)
            if ( $this->is_portal_page() ) {
                wp_enqueue_style( 'vendorhub-inventory-login', plugins_url( 'assets/app.css', __FILE__ ), array(), self::VERSION );
            }
            return;
        }

        // Only enqueue on portal page OR when shortcode is present in post_content (classic editor)
        $should = false;

        if ( $this->is_portal_page() ) {
            $should = true;
        } else {
            global $post;
            if ( $post && isset( $post->post_content ) && has_shortcode( $post->post_content, self::SHORTCODE ) ) {
                $should = true;
            }
        }

        if ( ! $should ) { return; }

        $opts = self::get_options();

        // We still enqueue the CSS file so it exists in cache; JS injects CSS into Shadow DOM.
        wp_enqueue_style( 'vendorhub-inventory', plugins_url( 'assets/app.css', __FILE__ ), array(), self::VERSION );

        wp_enqueue_script( 'vendorhub-inventory', plugins_url( 'assets/app.js', __FILE__ ), array(), self::VERSION, true );

        $css_text = '';
        $css_path = plugin_dir_path( __FILE__ ) . 'assets/app.css';
        if ( file_exists( $css_path ) ) {
            $css_text = file_get_contents( $css_path );
        }

        $export_nonce = wp_create_nonce( 'vendorhub_export_audit' );

        wp_localize_script( 'vendorhub-inventory', 'VENDORHUB', array(
            'restUrl'     => esc_url_raw( rest_url( 'vendorhub/v1' ) ),
            'nonce'       => wp_create_nonce( 'wp_rest' ),
            'cssText'     => $css_text,
            'low'         => intval( $opts['low_stock'] ),
            'exportUrl'   => admin_url( 'admin-ajax.php?action=vendorhub_audit_export' ),
            'exportNonce' => $export_nonce,
            'title'       => $this->get_portal_title(),
        ) );
    }

    
    /* ---------------------------
     * Portal title / store name
     * --------------------------- */
    private function get_portal_title() {
        // Default
        $title = 'VendorHub Inventory';

        $user = wp_get_current_user();
        if ( $user && $user->ID && $this->user_is_allowed_user( $user->ID ) ) {
            $store = $this->get_store_name_for_user( $user->ID );
            if ( $store ) {
                $title = $store;
            }
        }

        /**
         * Filter the header/title shown in the VendorHub app.
         * Return any string you want.
         */
        $title = apply_filters( 'vendorhub_inventory_title', $title, $user );

        return $title;
    }

    private function get_store_name_for_user( $user_id ) {
        $user_id = absint( $user_id );
        if ( ! $user_id ) return '';

        // WCFM Marketplace
        if ( function_exists( 'wcfmmp_get_store' ) ) {
            $store = wcfmmp_get_store( $user_id );
            if ( $store && method_exists( $store, 'get_shop_name' ) ) {
                $name = $store->get_shop_name();
                if ( $name ) return $name;
            }
        }

        if ( function_exists( 'wcfmmp_get_store_info' ) ) {
            $info = wcfmmp_get_store_info( $user_id );
            if ( is_array( $info ) && ! empty( $info['store_name'] ) ) return $info['store_name'];
        }

        // Dokan
        if ( function_exists( 'dokan_get_store_info' ) ) {
            $info = dokan_get_store_info( $user_id );
            if ( is_array( $info ) && ! empty( $info['store_name'] ) ) return $info['store_name'];
        }

        // WC Vendors
        if ( class_exists( 'WCV_Vendors' ) && method_exists( 'WCV_Vendors', 'get_vendor_shop_name' ) ) {
            $name = WCV_Vendors::get_vendor_shop_name( $user_id );
            if ( $name ) return $name;
        }

        // Fallback
        $u = get_userdata( $user_id );
        if ( $u && ! empty( $u->display_name ) ) return $u->display_name;

        return '';
    }

    /**
     * Ensure login from VendorHub portal stays on VendorHub portal (not WCFM dashboard).
     * We mark our redirect with ?vendorhub=1 and force it here.
     */
    public function filter_login_redirect( $redirect_to, $requested_redirect_to, $user ) {
        if ( is_wp_error( $user ) || ! $user ) {
            return $redirect_to;
        }

        $portal = $this->get_portal_url();
        if ( ! $portal ) {
            return $redirect_to;
        }

        $req = is_string( $requested_redirect_to ) ? $requested_redirect_to : '';
        if ( $req && strpos( $req, 'vendorhub=1' ) !== false ) {
            return wp_validate_redirect( $req, $portal );
        }

        // Extra safety: if user came from our portal page and is vendor, keep them here.
        $ref = isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '';
        if ( $ref && $this->user_is_allowed_user( $user->ID ) ) {
            $portal_cmp = untrailingslashit( $portal );
            if ( strpos( $ref, $portal_cmp ) !== false ) {
                return $portal;
            }
        }

        return $redirect_to;
    }

    /**
     * Block non-vendors from authenticating via the VendorHub portal login form.
     * This prevents customers/wholesalers from logging in successfully and then seeing "Access denied".
     * Instead, they get a generic incorrect username/password style error.
     */
    public function restrict_vendorhub_portal_login( $user, $password ) {
        if ( is_wp_error( $user ) || ! $user ) {
            return $user;
        }

        // Only enforce this rule when the login attempt is coming from our portal form.
        if ( ! $this->is_vendorhub_portal_login_request() ) {
            return $user;
        }

        if ( ! $this->user_is_allowed_user( $user->ID ) ) {
            // Generic message on purpose.
            return new WP_Error( 'invalid_login', __( 'Incorrect username or password.' ) );
        }

        return $user;
    }

    private function is_vendorhub_portal_login_request() {
        // Our custom portal login form posts these fields (so we can restrict only portal logins).
        if ( isset( $_POST['vh_login'] ) && isset( $_POST['vh_nonce'] ) ) {
            return true;
        }

        // Legacy (older versions): login form sets redirect_to to the portal URL with ?vendorhub=1.
        $redirect_to = isset( $_REQUEST['redirect_to'] ) ? (string) wp_unslash( $_REQUEST['redirect_to'] ) : '';
        if ( $redirect_to && strpos( $redirect_to, 'vendorhub=1' ) !== false ) {
            return true;
        }

        // Fallback: referrer check (some plugins rewrite redirect_to).
        $ref = isset( $_SERVER['HTTP_REFERER'] ) ? (string) wp_unslash( $_SERVER['HTTP_REFERER'] ) : '';
        $portal = $this->get_portal_url();
        if ( $portal && $ref ) {
            $portal_cmp = untrailingslashit( $portal );
            if ( strpos( $ref, $portal_cmp ) !== false && isset( $_POST['log'] ) && isset( $_POST['pwd'] ) ) {
                return true;
            }
        }

        return false;
    }

    private function get_portal_url() {
        $page_id = self::get_portal_page_id();
        if ( $page_id ) {
            $url = get_permalink( $page_id );
            if ( $url ) return $url;
        }
        return '';
    }


    /**
     * Stored portal page ID (created on activation). This was missing in v88 and caused a fatal error on login.
     */
    public static function get_portal_page_id() {
        return intval( get_option( self::PAGE_OPT, 0 ) );
    }

    /**
     * Daily self-heal: ensure the portal page still exists and contains the shortcode.
     */
    public static function run_self_heal() {
        // Ensure DB tables exist (safe no-op after first run)
        self::create_tables();

        $pid  = intval( get_option( self::PAGE_OPT, 0 ) );
        $page = $pid ? get_post( $pid ) : null;

        // If missing or trashed, recreate
        if ( ! $page || ! isset( $page->ID ) || $page->post_type !== 'page' || $page->post_status === 'trash' ) {
            update_option( self::PAGE_OPT, 0 );
            self::maybe_create_portal_page();
            return;
        }

        // Ensure published
        if ( $page->post_status !== 'publish' ) {
            wp_update_post( array(
                'ID'          => $pid,
                'post_status' => 'publish',
            ) );
        }

        // Ensure shortcode exists in content (without duplicating)
        $content = (string) $page->post_content;
        $has = function_exists( 'has_shortcode' ) ? has_shortcode( $content, self::SHORTCODE ) : ( strpos( $content, self::SHORTCODE ) !== false );
        if ( ! $has ) {
            $content = trim( $content );
            $content = $content . ( $content !== '' ? "

" : '' ) . self::portal_shortcode_content();
            wp_update_post( array(
                'ID'           => $pid,
                'post_content' => $content,
            ) );
        }
    }

    private function user_is_allowed_user( $user_id ) {
        $user_id = absint( $user_id );
        if ( ! $user_id ) return false;

        $opts = self::get_options();

        if ( $opts['allow_admin'] === 'yes' && user_can( $user_id, 'manage_woocommerce' ) ) {
            return true;
        }

        // If WCFM vendor role exists, enforce strict vendor-only access.
        $allowed = array();
        if ( get_role( 'wcfm_vendor' ) ) {
            $allowed = array( 'wcfm_vendor' );
            $allowed = (array) apply_filters( 'vendorhub_portal_allowed_roles', $allowed );
        }

        // Fallback: use configured roles (for non-WCFM marketplaces).
        if ( empty( $allowed ) ) {
            $raw = isset( $opts['allowed_roles'] ) ? $opts['allowed_roles'] : '';
            foreach ( explode( ',', $raw ) as $r ) {
                $r = sanitize_key( trim( $r ) );
                if ( $r ) $allowed[] = $r;
            }
        }

        $u = get_userdata( $user_id );
        if ( ! $u ) return false;

        $roles = is_array( $u->roles ) ? $u->roles : array();
        foreach ( $roles as $r ) {
            if ( in_array( $r, $allowed, true ) ) return true;
        }

        return false;
    }

/* ---------------------------
     * Vendor checks
     * --------------------------- */
    private function user_is_allowed() {
        $user = wp_get_current_user();
        if ( ! $user || ! $user->ID ) { return false; }

        $opts = self::get_options();

        if ( $opts['allow_admin'] === 'yes' && user_can( $user, 'manage_woocommerce' ) ) {
            return true;
        }

        // If WCFM vendor role exists, enforce strict vendor-only access.
        $allowed = array();
        if ( get_role( 'wcfm_vendor' ) ) {
            $allowed = array( 'wcfm_vendor' );
            $allowed = (array) apply_filters( 'vendorhub_portal_allowed_roles', $allowed );
        }

        // Fallback: use configured roles (for non-WCFM marketplaces).
        if ( empty( $allowed ) ) {
            $raw = isset( $opts['allowed_roles'] ) ? (string) $opts['allowed_roles'] : '';
            foreach ( explode( ',', $raw ) as $r ) {
                $r = trim( $r );
                if ( $r !== '' ) { $allowed[] = $r; }
            }
        }

        foreach ( (array) $user->roles as $role ) {
            if ( in_array( $role, $allowed, true ) ) { return true; }
        }

        return false;
    }

    private function user_is_vendor() {
        return $this->user_is_allowed();
    }

    private function user_has_2fa( $user_id ) {
        // Two-Factor plugin compatibility if installed
        if ( class_exists( 'Two_Factor_Core' ) && method_exists( 'Two_Factor_Core', 'is_user_using_two_factor' ) ) {
            return (bool) Two_Factor_Core::is_user_using_two_factor( $user_id );
        }
        // Generic meta used by some 2FA plugins
        $providers = get_user_meta( $user_id, 'two_factor_enabled_providers', true );
        if ( is_array( $providers ) && ! empty( $providers ) ) { return true; }

        // Allow custom integration
        return (bool) apply_filters( 'vendorhub_user_has_2fa', false, $user_id );
    }

    private function product_belongs_to_vendor( $product_id, $vendor_id ) {
        $post = get_post( $product_id );
        if ( ! $post ) { return false; }
        return intval( $post->post_author ) === intval( $vendor_id );
    }

    /* ---------------------------
     * Rate limiting
     * --------------------------- */
    private function get_client_ip() {
        $ip = '';
        if ( isset( $_SERVER['REMOTE_ADDR'] ) ) {
            $ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
        }
        return $ip ? $ip : '0.0.0.0';
    }

    private function rate_limit_check( $bucket, $limit_per_min ) {
        $user_id = get_current_user_id();
        $ip = $this->get_client_ip();
        $key = 'vh_rl_' . md5( $bucket . '|' . $user_id . '|' . $ip );

        $now = time();
        $data = get_transient( $key );
        if ( ! is_array( $data ) ) {
            $data = array( 'reset' => $now + 60, 'count' => 0 );
        }

        if ( $now > intval( $data['reset'] ) ) {
            $data = array( 'reset' => $now + 60, 'count' => 0 );
        }

        $data['count'] = intval( $data['count'] ) + 1;
        set_transient( $key, $data, 70 );

        if ( $data['count'] > intval( $limit_per_min ) ) {
            return new WP_Error( 'vendorhub_rate_limited', 'Rate limit exceeded. Try again.', array( 'status' => 429 ) );
        }

        return true;
    }

    /* ---------------------------
     * REST
     * --------------------------- */
    public function register_rest() {
        register_rest_route( 'vendorhub/v1', '/inventory', array(
            'methods'  => 'GET',
            'callback' => array( $this, 'rest_inventory' ),
            'permission_callback' => array( $this, 'rest_vendor_read' ),
        ) );

        register_rest_route( 'vendorhub/v1', '/stock/adjust', array(
            'methods'  => 'POST',
            'callback' => array( $this, 'rest_stock_adjust' ),
            'permission_callback' => array( $this, 'rest_vendor_write' ),
        ) );

        register_rest_route( 'vendorhub/v1', '/stock/set', array(
            'methods'  => 'POST',
            'callback' => array( $this, 'rest_stock_set' ),
            'permission_callback' => array( $this, 'rest_vendor_write' ),
        ) );

        register_rest_route( 'vendorhub/v1', '/audit', array(
            'methods'  => 'GET',
            'callback' => array( $this, 'rest_audit' ),
            'permission_callback' => array( $this, 'rest_vendor_read' ),
        ) );

        register_rest_route( 'vendorhub/v1', '/barcode/resolve', array(
            'methods'  => 'GET',
            'callback' => array( $this, 'rest_barcode_resolve' ),
            'permission_callback' => array( $this, 'rest_vendor_read' ),
        ) );
    }

    public function rest_vendor_read() {
        if ( ! is_user_logged_in() || ! $this->user_is_vendor() ) {
            return new WP_Error( 'vendorhub_forbidden', 'Forbidden', array( 'status' => 403 ) );
        }
        $opts = self::get_options();
        return $this->rate_limit_check( 'read', intval( $opts['rate_read_per_min'] ) );
    }

    public function rest_vendor_write() {
        if ( ! is_user_logged_in() || ! $this->user_is_vendor() ) {
            return new WP_Error( 'vendorhub_forbidden', 'Forbidden', array( 'status' => 403 ) );
        }
        $opts = self::get_options();
        return $this->rate_limit_check( 'write', intval( $opts['rate_write_per_min'] ) );
    }

    public function rest_inventory( WP_REST_Request $request ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return $this->json( array( 'error' => 'WooCommerce not active.' ), 400 );
        }

        $opts = self::get_options();
        $vendor_id = get_current_user_id();
        $page = max( 1, intval( $request->get_param( 'page' ) ) );
        $per  = max( 20, intval( $opts['per_page'] ) );

        // Query vendor products
        $args = array(
            'post_type'      => 'product',
            'post_status'    => array( 'publish', 'private', 'draft' ),
            'author'         => $vendor_id,
            'fields'         => 'ids',
            'posts_per_page' => $per,
            'paged'          => $page,
        );

        $q = new WP_Query( $args );

        $items = array();

        foreach ( $q->posts as $pid ) {
            $product = wc_get_product( $pid );
            if ( ! $product ) { continue; }

            $type = $product->get_type();

            if ( $type === 'variable' ) {
                $children = $product->get_children();
                foreach ( (array) $children as $vid ) {
                    $v = wc_get_product( $vid );
                    if ( ! $v ) { continue; }
                    $items[] = $this->format_product_item( $product, $v );
                }
            } else {
                $items[] = $this->format_product_item( $product, null );
            }
        }

        $pages = (int) $q->max_num_pages;

        return $this->json( array(
            'items' => $items,
            'page'  => $page,
            'pages' => max( 1, $pages ),
        ) );
    }

    private function format_product_item( $product, $variation ) {
        $p = $variation ? $variation : $product;
        $sku = (string) $p->get_sku();
        $name = (string) $product->get_name();
        if ( $variation ) {
            $name = $name . ' — ' . wc_get_formatted_variation( $variation, true, false, true );
        }

        $managing = (bool) $p->managing_stock();
        $qty = $managing ? $p->get_stock_quantity() : null;

        $price = $p->get_price();
        if ( $price === '' ) { $price = null; }

        return array(
            'product_id'     => (int) $product->get_id(),
            'variation_id'   => $variation ? (int) $variation->get_id() : 0,
            'sku'            => $sku,
            'name'           => $name,
            'price'          => $price !== null ? (float) $price : null,
            'stock_qty'      => $qty !== null ? (int) $qty : null,
            'managing_stock' => $managing,
            'type'           => $variation ? 'variation' : $product->get_type(),
        );
    }

    public function rest_stock_adjust( WP_REST_Request $request ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return $this->json( array( 'error' => 'WooCommerce not active.' ), 400 );
        }

        $vendor_id = get_current_user_id();

        $product_id   = intval( $request->get_param( 'product_id' ) );
        $variation_id = intval( $request->get_param( 'variation_id' ) );
        $delta        = intval( $request->get_param( 'delta' ) );
        $reason       = sanitize_text_field( (string) $request->get_param( 'reason' ) );
        $source       = sanitize_text_field( (string) $request->get_param( 'source' ) );

        if ( ! $product_id || ! $this->product_belongs_to_vendor( $product_id, $vendor_id ) ) {
            return $this->json( array( 'error' => 'Invalid product.' ), 403 );
        }

        $target_id = $variation_id ? $variation_id : $product_id;
        $p = wc_get_product( $target_id );
        if ( ! $p ) { return $this->json( array( 'error' => 'Not found.' ), 404 ); }

        // ensure stock managed so vendor can "reactivate" items
        if ( ! $p->managing_stock() ) {
            $p->set_manage_stock( true );
            $p->set_stock_quantity( 0 );
        }

        $old = (int) $p->get_stock_quantity();
        $new = max( 0, $old + $delta );

        $p->set_stock_quantity( $new );
        $p->set_stock_status( $new > 0 ? 'instock' : 'outofstock' );
        $p->save();

        $sku = (string) $p->get_sku();
        $this->insert_audit( $vendor_id, $product_id, $variation_id, $sku, $delta, $new, $reason ? $reason : 'manual', $source ? $source : 'manual' );

        return $this->json( array(
            'old_qty' => $old,
            'new_qty' => $new,
        ) );
    }

    public function rest_stock_set( WP_REST_Request $request ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return $this->json( array( 'error' => 'WooCommerce not active.' ), 400 );
        }

        $vendor_id = get_current_user_id();

        $product_id   = intval( $request->get_param( 'product_id' ) );
        $variation_id = intval( $request->get_param( 'variation_id' ) );
        $qty          = intval( $request->get_param( 'quantity' ) );
        $reason       = sanitize_text_field( (string) $request->get_param( 'reason' ) );
        $source       = sanitize_text_field( (string) $request->get_param( 'source' ) );

        if ( $qty < 0 ) { $qty = 0; }

        if ( ! $product_id || ! $this->product_belongs_to_vendor( $product_id, $vendor_id ) ) {
            return $this->json( array( 'error' => 'Invalid product.' ), 403 );
        }

        $target_id = $variation_id ? $variation_id : $product_id;
        $p = wc_get_product( $target_id );
        if ( ! $p ) { return $this->json( array( 'error' => 'Not found.' ), 404 ); }

        if ( ! $p->managing_stock() ) {
            $p->set_manage_stock( true );
        }

        $old = (int) $p->get_stock_quantity();
        $new = max( 0, $qty );

        $delta = $new - $old;

        $p->set_stock_quantity( $new );
        $p->set_stock_status( $new > 0 ? 'instock' : 'outofstock' );
        $p->save();

        $sku = (string) $p->get_sku();
        $this->insert_audit( $vendor_id, $product_id, $variation_id, $sku, $delta, $new, $reason ? $reason : 'manual', $source ? $source : 'manual' );

        return $this->json( array(
            'old_qty' => $old,
            'new_qty' => $new,
        ) );
    }

    public function rest_audit( WP_REST_Request $request ) {
        global $wpdb;
        $vendor_id = get_current_user_id();

        $page = max( 1, intval( $request->get_param( 'page' ) ) );
        $per  = 50;
        $off  = ( $page - 1 ) * $per;

        $table = self::table_audit();

        $total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE vendor_id = %d",
            $vendor_id
        ) );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT sku, delta, new_qty, reason, source, created_at
             FROM {$table}
             WHERE vendor_id = %d
             ORDER BY id DESC
             LIMIT %d OFFSET %d",
            $vendor_id, $per, $off
        ), ARRAY_A );

        $pages = (int) ceil( $total / $per );
        if ( $pages < 1 ) { $pages = 1; }

        return $this->json( array(
            'rows'  => $rows ? $rows : array(),
            'page'  => $page,
            'pages' => $pages,
        ) );
    }

    public function rest_barcode_resolve( WP_REST_Request $request ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return $this->json( array( 'error' => 'WooCommerce not active.' ), 400 );
        }

        $vendor_id = get_current_user_id();
        $code = sanitize_text_field( (string) $request->get_param( 'code' ) );
        $code = trim( $code );
        if ( $code === '' ) {
            return $this->json( array( 'error' => 'Missing code.' ), 400 );
        }

        // First try SKU directly (fast)
        $pid = wc_get_product_id_by_sku( $code );
        if ( $pid ) {
            if ( $this->product_belongs_to_vendor( $pid, $vendor_id ) ) {
                $product = wc_get_product( $pid );
                if ( $product ) {
                    return $this->json( array(
                        'product_id'   => (int) $pid,
                        'variation_id' => 0,
                        'sku'          => (string) $product->get_sku(),
                        'name'         => (string) $product->get_name(),
                    ) );
                }
            }
        }

        // Then try barcode meta keys for vendor products (safe but slower)
        $opts = self::get_options();
        $keys = array();
        foreach ( explode( ',', (string) $opts['barcode_meta_keys'] ) as $k ) {
            $k = trim( $k );
            if ( $k !== '' ) { $keys[] = $k; }
        }

        if ( empty( $keys ) ) {
            return $this->json( array( 'error' => 'Not found.' ), 404 );
        }

        // Search products authored by vendor with matching meta
        $meta_query = array( 'relation' => 'OR' );
        foreach ( $keys as $k ) {
            $meta_query[] = array(
                'key'   => $k,
                'value' => $code,
                'compare' => '=',
            );
        }

        $q = new WP_Query( array(
            'post_type'      => array( 'product', 'product_variation' ),
            'post_status'    => array( 'publish', 'private', 'draft' ),
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'meta_query'     => $meta_query,
        ) );

        if ( ! empty( $q->posts ) ) {
            $found = intval( $q->posts[0] );
            // If variation, map to parent product
            $variation_id = 0;
            $product_id = $found;

            $post = get_post( $found );
            if ( $post && $post->post_type === 'product_variation' ) {
                $variation_id = $found;
                $product_id = (int) $post->post_parent;
            }

            if ( $product_id && $this->product_belongs_to_vendor( $product_id, $vendor_id ) ) {
                $prod = wc_get_product( $variation_id ? $variation_id : $product_id );
                $parent = wc_get_product( $product_id );
                return $this->json( array(
                    'product_id'   => (int) $product_id,
                    'variation_id' => (int) $variation_id,
                    'sku'          => $prod ? (string) $prod->get_sku() : '',
                    'name'         => $parent ? (string) $parent->get_name() : '',
                ) );
            }
        }

        return $this->json( array( 'error' => 'Not found.' ), 404 );
    }

    private function insert_audit( $vendor_id, $product_id, $variation_id, $sku, $delta, $new_qty, $reason, $source ) {
        global $wpdb;

        $table = self::table_audit();
        $wpdb->insert(
            $table,
            array(
                'vendor_id'    => (int) $vendor_id,
                'product_id'   => (int) $product_id,
                'variation_id' => (int) $variation_id,
                'sku'          => (string) $sku,
                'delta'        => (int) $delta,
                'new_qty'      => (int) $new_qty,
                'reason'       => (string) $reason,
                'source'       => (string) $source,
                'ip'           => (string) $this->get_client_ip(),
                'user_id'      => (int) get_current_user_id(),
                'created_at'   => gmdate( 'Y-m-d H:i:s' ),
            ),
            array( '%d','%d','%d','%s','%d','%d','%s','%s','%s','%d','%s' )
        );
    }

    private function json( $data, $status = 200 ) {
        return new WP_REST_Response( $data, $status );
    }

    /* ---------------------------
     * Audit CSV export (ajax)
     * --------------------------- */
    public function ajax_audit_export() {
        if ( ! is_user_logged_in() || ! $this->user_is_vendor() ) {
            wp_die( 'Forbidden', 403 );
        }
        $nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'vendorhub_export_audit' ) ) {
            wp_die( 'Bad nonce', 403 );
        }

        global $wpdb;
        $vendor_id = get_current_user_id();
        $table = self::table_audit();

        $limit = isset( $_GET['limit'] ) ? intval( $_GET['limit'] ) : 5000;
        if ( $limit < 1 ) { $limit = 5000; }
        if ( $limit > 20000 ) { $limit = 20000; }

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT created_at, sku, delta, new_qty, reason, source
             FROM {$table}
             WHERE vendor_id = %d
             ORDER BY id DESC
             LIMIT %d",
            $vendor_id, $limit
        ), ARRAY_A );

        $filename = 'vendorhub-audit-' . gmdate('Ymd-His') . '.csv';

        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=' . $filename );

        $out = fopen( 'php://output', 'w' );
        fputcsv( $out, array( 'created_at', 'sku', 'delta', 'new_qty', 'reason', 'source' ) );

        if ( $rows ) {
            foreach ( $rows as $r ) {
                fputcsv( $out, array(
                    $r['created_at'],
                    $r['sku'],
                    $r['delta'],
                    $r['new_qty'],
                    $r['reason'],
                    $r['source'],
                ) );
            }
        }
        fclose( $out );
        exit;
    }

    /* ---------------------------
     * WCFM menu (optional)
     * --------------------------- */
    public function filter_wcfm_menus( $menus ) {
        if ( ! is_array( $menus ) ) { return $menus; }
        $pid = intval( get_option( self::PAGE_OPT, 0 ) );
        if ( ! $pid ) { return $menus; }
        $url = get_permalink( $pid );
        if ( ! $url ) { return $menus; }

        $menus['vendorhub_inventory'] = array(
            'label' => 'Inventory',
            'url'   => $url,
            'icon'  => 'inventory',
            'priority' => 75,
        );
        return $menus;
    }

    /* ---------------------------
     * Admin settings
     * --------------------------- */
    public function admin_menu() {
        // WP-Admin access for site admins / developers (capability-based).
        // This lets you grant access to a developer account without giving full administrator access.
        $cap = self::CAP;

        add_menu_page(
            'VendorHub Inventory',
            'VendorHub Inventory',
            $cap,
            'vendorhub-inventory',
            array( $this, 'render_admin_home' ),
            'dashicons-clipboard',
            56
        );

        add_submenu_page(
            'vendorhub-inventory',
            'Open Portal',
            'Open Portal',
            $cap,
            'vendorhub-inventory-portal',
            array( $this, 'render_admin_portal_redirect' )
        );

        add_submenu_page(
            'vendorhub-inventory',
            'Settings',
            'Settings',
            $cap,
            'vendorhub-inventory-settings',
            array( $this, 'render_settings' )
        );

        add_submenu_page(
            'vendorhub-inventory',
            'Audit Log',
            'Audit Log',
            $cap,
            'vendorhub-inventory-audit',
            array( $this, 'render_admin_audit' )
        );

        // Legacy location (Settings → VendorHub Inventory) for older installs/bookmarks.
        add_options_page(
            'VendorHub Inventory',
            'VendorHub Inventory',
            $cap,
            'vendorhub-inventory-legacy',
            array( $this, 'render_settings' )
        );
    }

    public function admin_init() {
        register_setting( 'vendorhub_inventory', self::OPT_KEY, array( $this, 'sanitize_options' ) );
    }

    public function sanitize_options( $opts ) {
        $d = self::default_options();
        $o = is_array( $opts ) ? $opts : array();

        $out = array();
        $out['allowed_roles'] = isset( $o['allowed_roles'] ) ? sanitize_text_field( $o['allowed_roles'] ) : $d['allowed_roles'];
        $out['allow_admin']   = ( isset( $o['allow_admin'] ) && $o['allow_admin'] === 'yes' ) ? 'yes' : 'no';
        $out['low_stock']     = isset( $o['low_stock'] ) ? max( 0, intval( $o['low_stock'] ) ) : $d['low_stock'];
        $out['per_page']      = isset( $o['per_page'] ) ? max( 20, intval( $o['per_page'] ) ) : $d['per_page'];
        $out['rate_read_per_min']  = isset( $o['rate_read_per_min'] ) ? max( 30, intval( $o['rate_read_per_min'] ) ) : $d['rate_read_per_min'];
        $out['rate_write_per_min'] = isset( $o['rate_write_per_min'] ) ? max( 10, intval( $o['rate_write_per_min'] ) ) : $d['rate_write_per_min'];
        $out['barcode_meta_keys']  = isset( $o['barcode_meta_keys'] ) ? sanitize_text_field( $o['barcode_meta_keys'] ) : $d['barcode_meta_keys'];
        $out['require_2fa']   = ( isset( $o['require_2fa'] ) && $o['require_2fa'] === 'yes' ) ? 'yes' : 'no';

        return $out;
    }

    
    public function handle_recreate_page() {
        if ( ! current_user_can( self::CAP ) ) { wp_die( 'Forbidden', 403 ); }
        check_admin_referer( 'vendorhub_inventory_recreate_page' );
        // clear stored id and recreate
        update_option( self::PAGE_OPT, 0 );
        self::maybe_create_portal_page();
        wp_safe_redirect( admin_url( 'options-general.php?page=vendorhub-inventory' ) );
        exit;
    }

    /* ---------------------------
     * WP-Admin UI
     * --------------------------- */
    public function render_admin_home() {
        if ( ! current_user_can( self::CAP ) ) {
            wp_die( 'You do not have permission to access this page.' );
        }

        $portal_id  = self::get_portal_page_id();
        $portal_url = $portal_id ? get_permalink( $portal_id ) : '';
        ?>
        <div class="wrap">
            <h1>VendorHub Inventory</h1>
            <p>This plugin is vendor-first. WP-Admin access exists for site admins / developers to configure, debug, and open the vendor portal.</p>

            <div style="margin-top:16px; display:flex; gap:10px; flex-wrap:wrap;">
                <a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=vendorhub-inventory-portal' ) ); ?>">Open Portal</a>
                <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=vendorhub-inventory-settings' ) ); ?>">Settings</a>
                <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=vendorhub-inventory-audit' ) ); ?>">Audit Log</a>
            </div>

            <hr style="margin:18px 0;">

            <h2>Give access to a developer (without full admin)</h2>
            <ol>
                <li>Go to <strong>Users → Add New</strong></li>
                <li>Choose role: <strong>VendorHub Developer</strong></li>
                <li>That user will only see the VendorHub Inventory menu (plus basic WP dashboard), not full site admin features.</li>
            </ol>

            <?php if ( $portal_url ) : ?>
                <p><strong>Portal page:</strong> <a href="<?php echo esc_url( $portal_url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $portal_url ); ?></a></p>
            <?php else : ?>
                <p><strong>Portal page:</strong> Not set yet. Go to Settings and click “Recreate portal page”.</p>
            <?php endif; ?>
        </div>
        <?php
    }

    public function render_admin_portal_redirect() {
        if ( ! current_user_can( self::CAP ) ) {
            wp_die( 'You do not have permission to access this page.' );
        }

        $portal_id = self::get_portal_page_id();
        if ( ! $portal_id ) {
            self::maybe_create_portal_page();
            $portal_id = self::get_portal_page_id();
        }

        $url = $portal_id ? get_permalink( $portal_id ) : admin_url( 'admin.php?page=vendorhub-inventory-settings' );
        wp_safe_redirect( $url );
        exit;
    }

    public function render_admin_audit() {
        if ( ! current_user_can( self::CAP ) ) {
            wp_die( 'You do not have permission to access this page.' );
        }

        global $wpdb;
        $table = self::table_audit();
        $rows  = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC LIMIT 200", ARRAY_A );

        ?>
        <div class="wrap">
            <h1>VendorHub Inventory – Audit Log</h1>
            <p>Latest 200 stock changes recorded by the portal.</p>

            <p>
                <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=vendorhub-inventory-settings' ) ); ?>">Settings</a>
                <a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=vendorhub-inventory-portal' ) ); ?>">Open Portal</a>
            </p>

            <table class="widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Vendor</th>
                        <th>Product</th>
                        <th>SKU</th>
                        <th>Old</th>
                        <th>New</th>
                        <th>Delta</th>
                        <th>Time</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ( empty( $rows ) ) : ?>
                    <tr><td colspan="8">No audit records yet.</td></tr>
                <?php else : ?>
                    <?php foreach ( $rows as $r ) : ?>
                        <tr>
                            <td><?php echo esc_html( $r['id'] ); ?></td>
                            <td><?php echo esc_html( $r['vendor_id'] ); ?></td>
                            <td><?php echo esc_html( $r['variation_id'] && $r['variation_id'] != 0 ? $r['variation_id'] : $r['product_id'] ); ?></td>
                            <td><?php echo esc_html( $r['sku'] ); ?></td>
                            <td><?php echo esc_html( $r['old_stock'] ); ?></td>
                            <td><?php echo esc_html( $r['new_stock'] ); ?></td>
                            <td><?php echo esc_html( $r['delta'] ); ?></td>
                            <td><?php echo esc_html( $r['created_at'] ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

public function render_settings() {
        if ( ! current_user_can( self::CAP ) ) { return; }

        $opts = self::get_options();
        $pid  = intval( get_option( self::PAGE_OPT, 0 ) );
        ?>
        <div class="wrap">
            <h1>VendorHub Inventory</h1>
            <p><b>Shortcode:</b> <code>[<?php echo esc_html( self::SHORTCODE ); ?> show_login="yes"]</code></p>
            <p><b>Portal page:</b> <?php echo $pid ? '<a href="' . esc_url( get_permalink( $pid ) ) . '" target="_blank">Open</a>' : 'Not set'; ?></p>
            <p><a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=vendorhub_inventory_recreate_page' ), 'vendorhub_inventory_recreate_page' ) ); ?>">Recreate portal page</a></p>

            <form method="post" action="options.php">
                <?php settings_fields( 'vendorhub_inventory' ); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row">Allowed roles</th>
                        <td>
                            <input type="text" name="<?php echo esc_attr( self::OPT_KEY ); ?>[allowed_roles]" value="<?php echo esc_attr( $opts['allowed_roles'] ); ?>" class="regular-text" />
                            <p class="description">Comma-separated role slugs. Example: <code>wcfm_vendor</code></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Allow admin</th>
                        <td>
                            <label><input type="checkbox" name="<?php echo esc_attr( self::OPT_KEY ); ?>[allow_admin]" value="yes" <?php checked( $opts['allow_admin'], 'yes' ); ?> /> Let admins access the app</label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Low stock threshold</th>
                        <td><input type="number" min="0" name="<?php echo esc_attr( self::OPT_KEY ); ?>[low_stock]" value="<?php echo esc_attr( $opts['low_stock'] ); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Inventory per page</th>
                        <td><input type="number" min="20" name="<?php echo esc_attr( self::OPT_KEY ); ?>[per_page]" value="<?php echo esc_attr( $opts['per_page'] ); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Rate limit (read / min)</th>
                        <td><input type="number" min="30" name="<?php echo esc_attr( self::OPT_KEY ); ?>[rate_read_per_min]" value="<?php echo esc_attr( $opts['rate_read_per_min'] ); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Rate limit (write / min)</th>
                        <td><input type="number" min="10" name="<?php echo esc_attr( self::OPT_KEY ); ?>[rate_write_per_min]" value="<?php echo esc_attr( $opts['rate_write_per_min'] ); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Barcode meta keys</th>
                        <td>
                            <input type="text" name="<?php echo esc_attr( self::OPT_KEY ); ?>[barcode_meta_keys]" value="<?php echo esc_attr( $opts['barcode_meta_keys'] ); ?>" class="regular-text" />
                            <p class="description">Comma-separated meta keys used by your barcode/EAN plugin.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Require 2FA</th>
                        <td>
                            <label><input type="checkbox" name="<?php echo esc_attr( self::OPT_KEY ); ?>[require_2fa]" value="yes" <?php checked( $opts['require_2fa'], 'yes' ); ?> /> Block access unless user has 2FA enabled (Two-Factor plugin supported; others via filter)</label>
                        </td>
                    </tr>
                </table>

                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}

register_activation_hook( __FILE__, array( 'VendorHub_Inventory_Manager', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'VendorHub_Inventory_Manager', 'deactivate' ) );
add_action( 'plugins_loaded', array( 'VendorHub_Inventory_Manager', 'instance' ) );
