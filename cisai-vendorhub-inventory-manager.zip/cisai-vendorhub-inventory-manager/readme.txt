=== VendorHub Inventory Manager (Stock-only) ===
Contributors: vendorhub
Tags: woocommerce, inventory, sku, vendor
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.0
Stable tag: 1.3.1

Mobile-first vendor inventory manager for WooCommerce multi-vendor sites.

Shortcode:
[vendorhub_inventory show_login="yes"]

Notes:
- Camera scanning requires HTTPS (browser restriction).
- Vendors only see/edit their own products (post_author check).
