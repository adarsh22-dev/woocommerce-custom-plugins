/* VendorHub Inventory Manager - UI v1.2.3 (vanilla JS, Shadow DOM, stock-only) */
(function(){
  if (!window.VENDORHUB) return;
  var cfg = window.VENDORHUB;

  var host = document.getElementById("vendorhub-app");
  if (!host) return;

  var shadow = host.attachShadow ? host.attachShadow({ mode: "open" }) : null;
  var mount = document.createElement("div");
  mount.id = "vendorhub-app";

  if (shadow) {
    var style = document.createElement("style");
    style.textContent = String(cfg.cssText || "");
    shadow.appendChild(style);
    shadow.appendChild(mount);
  } else {
    host.appendChild(mount);
  }

  function $(sel, el){ return (el||mount).querySelector(sel); }
  function $$(sel, el){ return Array.prototype.slice.call((el||mount).querySelectorAll(sel)); }
  function esc(s){
    s = String(s==null ? "" : s);
    return s.replace(/[&<>"']/g, function(m){ return ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[m]); });
  }
  function svg(inner, stroke){
    return '<svg class="vh-ico" viewBox="0 0 24 24" aria-hidden="true" ' + (stroke ? '' : 'fill="currentColor"') + '>' + inner + '</svg>';
  }

  var icon = {
    search: svg('<path d="M10 18a8 8 0 1 1 5.3-2l4.2 4.2-1.4 1.4-4.2-4.2A7.9 7.9 0 0 1 10 18Zm0-2a6 6 0 1 0 0-12 6 6 0 0 0 0 12Z"/>'),
    refresh: svg('<path d="M20 12a8 8 0 1 1-2.34-5.66l-1.42 1.42A6 6 0 1 0 18 12h-3l4 4 4-4h-3Z"/>'),
    sync: svg('<path d="M12 4V1L8 5l4 4V6a6 6 0 0 1 5.66 4H20a8 8 0 0 0-8-6ZM6.34 14H4a8 8 0 0 0 8 6v3l4-4-4-4v3a6 6 0 0 1-5.66-4Z"/>'),
    list: svg('<path d="M4 6h16v2H4V6Zm0 5h16v2H4v-2Zm0 5h16v2H4v-2Z"/>'),
    box: svg('<path d="M21 8v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8m18 0-9 5-9-5m18 0-9-5-9 5" stroke="currentColor" stroke-width="2" fill="none" stroke-linejoin="round"/>', true),
    scan: svg('<path d="M7 4H4v3h2V6h1V4Zm13 0h-3v2h1v1h2V4ZM6 17H4v3h3v-2H6v-1Zm14 0h-2v1h-1v2h3v-3ZM7 11h10v2H7v-2Z"/>'),
    plus: svg('<path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6V5Z"/>'),
    minus: svg('<path d="M5 11h14v2H5v-2Z"/>'),
    set: svg('<path d="M5 3h14v2H5V3Zm0 16h14v2H5v-2Zm2-3h10v2H7v-2Zm0-10h10v2H7V6Z"/>'),
    export: svg('<path d="M12 2v10m0 0 3-3m-3 3-3-3M4 14v6h16v-6" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>', true),
    sort: svg('<path d="M7 6h10v2H7V6Zm0 5h7v2H7v-2Zm0 5h4v2H7v-2Z"/>'),
    close: svg('<path d="M6 6l12 12M18 6 6 18" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/>', true)
  };

  // State
  var state = {
    tab: "inv",
    search: "",
    filter: "all",
    sort: "sku",
    sortDir: "asc",
    invPage: 1,
    invPages: 1,
    auditPage: 1,
    auditPages: 1,
    items: [],
    audit: [],
    loadingInv: false,
    loadingAudit: false,
    queue: loadQueue(),
    pending: loadPending(),
    lastAction: null,
    autoRefresh: false,
    autoTimer: null,
    scanMode: "sale",
    scanning: false,
    camStream: null,
    lastScan: ""
  };

  function keyOf(it){
    return String(it.product_id||0) + ":" + String(it.variation_id||0) + ":" + String((it.sku||"").trim());
  }

  function loadQueue(){
    try { return JSON.parse(localStorage.getItem("vh_queue_v123") || "[]"); } catch(e){ return []; }
  }
  function saveQueue(){
    localStorage.setItem("vh_queue_v123", JSON.stringify(state.queue || []));
  }
  function loadPending(){
    try { return JSON.parse(localStorage.getItem("vh_pending_v123") || "{}"); } catch(e){ return {}; }
  }
  function savePending(){
    localStorage.setItem("vh_pending_v123", JSON.stringify(state.pending || {}));
  }

  function api(path, opts){
    opts = opts || {};
    var method = opts.method || "GET";
    var params = opts.params || null;
    var body = opts.body || null;

    var url = String(cfg.restUrl || "").replace(/\/$/, "") + path;
    if (params) {
      var usp = new URLSearchParams();
      for (var k in params) {
        if (!params.hasOwnProperty(k)) continue;
        var v = params[k];
        if (v === null || v === undefined || v === "") continue;
        usp.set(k, String(v));
      }
      var qs = usp.toString();
      if (qs) url += (url.indexOf("?") >= 0 ? "&" : "?") + qs;
    }

    var headers = { "X-WP-Nonce": cfg.nonce };
    if (body) headers["Content-Type"] = "application/json";

    return fetch(url, {
      method: method,
      headers: headers,
      credentials: "same-origin",
      body: body ? JSON.stringify(body) : undefined
    }).then(function(res){
      return res.json().catch(function(){ return null; }).then(function(data){
        if (!res.ok) {
          var msg = (data && data.error) ? data.error : ("HTTP " + res.status);
          var err = new Error(msg);
          err.status = res.status;
          err.data = data;
          throw err;
        }
        return data;
      });
    });
  }

  // UI shell
  mount.innerHTML = ''
    + '<div class="vh-topbar">'
    + '  <div class="vh-title">'
    + '    <h1 id="vh-title-text">VendorHub Inventory</h1>'
    + '    <div class="vh-actions">'
    + '      <button class="vh-iconbtn" id="vh-refresh" title="Refresh">' + icon.refresh + '<span class="lbl">Refresh</span></button>'
    + '      <button class="vh-iconbtn" id="vh-sync" title="Sync queued" style="display:none">' + icon.sync + '<span class="lbl">Sync</span><span class="vh-badge" id="vh-qbadge">0</span></button>'
    + '    </div>'
    + '  </div>'
    + '  <div class="vh-searchwrap">'
    + '    <div class="vh-search">' + icon.search + '<input id="vh-search" type="text" inputmode="search" placeholder="Search by SKU or name…" /></div>'
    + '    <button class="vh-iconbtn" id="vh-sort-open" title="Sort">' + icon.sort + '<span class="lbl"></span></button>'
    + '  </div>'
    + '  <div class="vh-chiprow" aria-label="Filters">'
    + '    <button class="vh-chip" data-filter="all" aria-pressed="true">All</button>'
    + '    <button class="vh-chip" data-filter="low" aria-pressed="false">Low</button>'
    + '    <button class="vh-chip" data-filter="out" aria-pressed="false">Out</button>'
    + '    <button class="vh-chip" data-filter="in" aria-pressed="false">In</button>'
    + '    <button class="vh-chip" id="vh-auto" aria-pressed="false">Auto</button>'
    + '  </div>'
    + '</div>'
    + '<div class="vh-shell"><div id="vh-view"></div></div>'
    + '<div class="vh-bottomnav"><div class="vh-navinner">'
    + '  <button class="vh-tabbtn" id="vh-tab-inv" aria-selected="true">' + icon.list + '<span>Inventory</span></button>'
    + '  <button class="vh-fab" id="vh-open-scan" title="Scan">' + icon.scan + '</button>'
    + '  <button class="vh-tabbtn" id="vh-tab-audit" aria-selected="false">' + icon.box + '<span>Audit</span></button>'
    + '</div></div>'
    + '<div class="vh-toastwrap" id="vh-toastwrap" style="display:none"></div>'

    + '<div class="vh-modal" id="vh-modal-set" role="dialog" aria-modal="true">'
    + '  <div class="vh-sheet">'
    + '    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px">'
    + '      <h2>Set quantity</h2>'
    + '      <button class="vh-iconbtn" id="vh-close-set" aria-label="Close">' + icon.close + '<span class="lbl">Close</span></button>'
    + '    </div>'
    + '    <p id="vh-set-sub">—</p>'
    + '    <div class="vh-field"><div class="vh-label">Quantity</div><input class="vh-input" id="vh-set-qty" type="number" min="0" step="1" inputmode="numeric" /></div>'
    + '    <div class="vh-btnrow" style="margin-top:12px">'
    + '      <button class="vh-btn" id="vh-set-cancel">Cancel</button>'
    + '      <button class="vh-btn primary" id="vh-set-save">' + icon.set + ' Save</button>'
    + '    </div>'
    + '  </div>'
    + '</div>'

    + '<div class="vh-modal" id="vh-modal-sort" role="dialog" aria-modal="true">'
    + '  <div class="vh-sheet">'
    + '    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px">'
    + '      <h2>Sort</h2>'
    + '      <button class="vh-iconbtn" id="vh-close-sort" aria-label="Close">' + icon.close + '<span class="lbl">Close</span></button>'
    + '    </div>'
    + '    <p>Choose sort field and direction.</p>'
    + '    <div class="vh-chiprow" style="margin-top:12px">'
    + '      <button class="vh-chip" data-sort="sku" aria-pressed="true">SKU</button>'
    + '      <button class="vh-chip" data-sort="name" aria-pressed="false">Name</button>'
    + '      <button class="vh-chip" data-sort="stock" aria-pressed="false">Stock</button>'
    + '    </div>'
    + '    <div class="vh-chiprow">'
    + '      <button class="vh-chip" data-dir="asc" aria-pressed="true">Asc</button>'
    + '      <button class="vh-chip" data-dir="desc" aria-pressed="false">Desc</button>'
    + '    </div>'
    + '    <div class="vh-btnrow" style="margin-top:12px">'
    + '      <button class="vh-btn" id="vh-sort-close">Close</button>'
    + '      <button class="vh-btn primary" id="vh-sort-apply">' + icon.sort + ' Apply</button>'
    + '    </div>'
    + '  </div>'
    + '</div>'

    + '<div class="vh-modal" id="vh-modal-scan" role="dialog" aria-modal="true">'
    + '  <div class="vh-sheet" style="padding-bottom:16px">'
    + '    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px">'
    + '      <h2>Scan</h2>'
    + '      <button class="vh-iconbtn" id="vh-close-scan" aria-label="Close">' + icon.close + '<span class="lbl">Close</span></button>'
    + '    </div>'
    + '    <p>Use camera if available. Fallback: type/paste code.</p>'
    + '    <div class="vh-scanbox">'
    + '      <video id="vh-video" playsinline muted></video>'
    + '      <div class="vh-kv"><span>Mode</span><span><span class="vh-pill" id="vh-mode-pill">Sale</span></span></div>'
    + '      <div class="vh-scanbar">'
    + '        <button class="vh-btn" id="vh-mode-sale">' + icon.minus + ' Sale</button>'
    + '        <button class="vh-btn" id="vh-mode-restock">' + icon.plus + ' Restock</button>'
    + '      </div>'
    + '      <div class="vh-field"><div class="vh-label">Code (SKU / barcode)</div><input class="vh-input" id="vh-scan-code" type="text" inputmode="text" placeholder="Scan or type code…" /></div>'
    + '      <div class="vh-btnrow" style="margin-top:10px">'
    + '        <button class="vh-btn" id="vh-start-cam">Start camera</button>'
    + '        <button class="vh-btn primary" id="vh-apply-code">' + icon.scan + ' Apply</button>'
    + '      </div>'
    + '      <div class="vh-kv"><span>Last</span><span id="vh-last-scan">—</span></div>'
    + '    </div>'
    + '  </div>'
    + '</div>';

  // Dynamic title
  try {
    var tEl = $("#vh-title-text");
    if (tEl) tEl.textContent = String(cfg.title || 'VendorHub Inventory');
  } catch(e) {}

  // Toast
  var toastTimer = null;
  function toast(msg, actionText, actionFn, ms){
    ms = ms || 3000;
    var wrap = $("#vh-toastwrap");
    wrap.style.display = "flex";
    wrap.innerHTML = ''
      + '<div class="vh-toast">'
      + '  <div class="msg">' + esc(msg) + '</div>'
      + (actionText ? ('<button class="act" id="vh-toast-act">' + esc(actionText) + '</button>') : '')
      + '</div>';

    if (toastTimer) window.clearTimeout(toastTimer);
    if (actionText) {
      var btn = $("#vh-toast-act", wrap);
      btn.addEventListener("click", function(e){
        e.preventDefault();
        if (actionFn) actionFn();
        hideToast();
      }, { once: true });
    }
    toastTimer = window.setTimeout(hideToast, ms);
  }
  function hideToast(){
    var wrap = $("#vh-toastwrap");
    wrap.style.display = "none";
    wrap.innerHTML = "";
  }

  // Modal helpers
  function openModal(m){ m.classList.add("open"); }
  function closeModal(m){ m.classList.remove("open"); }

  var modalSet  = $("#vh-modal-set");
  var modalSort = $("#vh-modal-sort");
  var modalScan = $("#vh-modal-scan");

  // Close buttons
  $("#vh-close-set").addEventListener("click", function(){ closeModal(modalSet); });
  $("#vh-set-cancel").addEventListener("click", function(){ closeModal(modalSet); });

  $("#vh-close-sort").addEventListener("click", function(){ closeModal(modalSort); });
  $("#vh-sort-close").addEventListener("click", function(){ closeModal(modalSort); });

  $("#vh-close-scan").addEventListener("click", function(){ stopCamera(); closeModal(modalScan); });

  [modalSet, modalSort, modalScan].forEach(function(m){
    m.addEventListener("click", function(e){
      if (e.target === m) {
        if (m === modalScan) stopCamera();
        closeModal(m);
      }
    });
  });

  // Sort modal state
  var tmpSort = { sort: state.sort, dir: state.sortDir };
  function syncSortUi(){
    $$("#vh-modal-sort [data-sort]").forEach(function(b){
      b.setAttribute("aria-pressed", (b.getAttribute("data-sort") === tmpSort.sort) ? "true" : "false");
    });
    $$("#vh-modal-sort [data-dir]").forEach(function(b){
      b.setAttribute("aria-pressed", (b.getAttribute("data-dir") === tmpSort.dir) ? "true" : "false");
    });
  }
  $$("#vh-modal-sort [data-sort]").forEach(function(b){
    b.addEventListener("click", function(){ tmpSort.sort = b.getAttribute("data-sort"); syncSortUi(); });
  });
  $$("#vh-modal-sort [data-dir]").forEach(function(b){
    b.addEventListener("click", function(){ tmpSort.dir = b.getAttribute("data-dir"); syncSortUi(); });
  });
  $("#vh-sort-apply").addEventListener("click", function(){
    state.sort = tmpSort.sort;
    state.sortDir = tmpSort.dir;
    closeModal(modalSort);
    render();
  });

  // Search/filter controls
  $("#vh-search").addEventListener("input", function(e){
    state.search = e.target.value || "";
    render();
  });

  $$(".vh-chip[data-filter]").forEach(function(btn){
    btn.addEventListener("click", function(){
      state.filter = btn.getAttribute("data-filter");
      $$(".vh-chip[data-filter]").forEach(function(b){
        b.setAttribute("aria-pressed", (b === btn) ? "true" : "false");
      });
      render();
    });
  });

  $("#vh-sort-open").addEventListener("click", function(){
    tmpSort = { sort: state.sort, dir: state.sortDir };
    syncSortUi();
    openModal(modalSort);
  });

  $("#vh-refresh").addEventListener("click", function(){
    if (state.tab === "inv") fetchInventory(1, false, false);
    else fetchAudit(1, false, false);
  });

  $("#vh-auto").addEventListener("click", function(){
    state.autoRefresh = !state.autoRefresh;
    $("#vh-auto").setAttribute("aria-pressed", state.autoRefresh ? "true" : "false");
    if (state.autoRefresh) {
      toast("Auto refresh on (20s).");
      if (state.autoTimer) window.clearInterval(state.autoTimer);
      state.autoTimer = window.setInterval(function(){
        if (state.tab === "inv") fetchInventory(1, false, true);
      }, 20000);
    } else {
      toast("Auto refresh off.");
      if (state.autoTimer) window.clearInterval(state.autoTimer);
      state.autoTimer = null;
    }
  });

  // Tabs
  $("#vh-tab-inv").addEventListener("click", function(){ state.tab = "inv"; render(); });
  $("#vh-tab-audit").addEventListener("click", function(){ state.tab = "audit"; render(); if (!state.audit.length) fetchAudit(1,false,true); });

  // Queue sync
  $("#vh-sync").addEventListener("click", function(){ syncQueue(); });

  // Scan
  $("#vh-open-scan").addEventListener("click", function(){
    openModal(modalScan);
    $("#vh-scan-code").focus();
  });
  $("#vh-mode-sale").addEventListener("click", function(){ setScanMode("sale"); });
  $("#vh-mode-restock").addEventListener("click", function(){ setScanMode("restock"); });
  $("#vh-start-cam").addEventListener("click", function(){ startCamera(); });
  $("#vh-apply-code").addEventListener("click", function(){ applyScanCode(null); });

  function setScanMode(mode){
    state.scanMode = mode;
    $("#vh-mode-pill").textContent = (mode === "sale") ? "Sale" : "Restock";
  }

  function shouldQueue(err){
    if (!err) return false;
    if (err.status === undefined) return true; // network fail
    if (err.status === 429) return true; // rate limit
    if (err.status === 403 || err.status === 401) return false;
    return false;
  }

  function markPending(key, on){
    if (on) state.pending[key] = true;
    else delete state.pending[key];
    savePending();
    render();
  }

  function optimisticSet(key, qty){
    for (var i=0;i<state.items.length;i++){
      if (keyOf(state.items[i]) === key){
        state.items[i].stock_qty = Math.max(0, qty);
        state.items[i].managing_stock = true;
        break;
      }
    }
    render();
  }
  function optimisticAdjust(key, delta){
    for (var i=0;i<state.items.length;i++){
      if (keyOf(state.items[i]) === key){
        var cur = (typeof state.items[i].stock_qty === "number") ? state.items[i].stock_qty : 0;
        state.items[i].stock_qty = Math.max(0, cur + delta);
        state.items[i].managing_stock = true;
        break;
      }
    }
    render();
  }

  // Set modal
  var setCtx = null;
  function openSet(btn){
    setCtx = {
      sku: btn.dataset.sku || "",
      product_id: parseInt(btn.dataset.pid || "0", 10) || 0,
      variation_id: parseInt(btn.dataset.vid || "0", 10) || 0,
      name: btn.dataset.name || "",
      old: btn.dataset.qty || ""
    };
    $("#vh-set-sub").textContent = (setCtx.name || "Product") + " • " + (setCtx.sku || "No SKU");
    $("#vh-set-qty").value = (setCtx.old === "—") ? "" : String(setCtx.old || "");
    openModal(modalSet);
    $("#vh-set-qty").focus();
  }

  $("#vh-set-save").addEventListener("click", function(){
    if (!setCtx) return;
    var qty = parseInt($("#vh-set-qty").value || "0", 10);
    if (isNaN(qty) || qty < 0) { toast("Enter a valid quantity (0 or more)."); return; }
    closeModal(modalSet);
    setQuantity(setCtx, qty, "manual", "manual");
  });

  function adjust(btn, delta, reason){
    var ctx = {
      sku: btn.dataset.sku || "",
      product_id: parseInt(btn.dataset.pid || "0", 10) || 0,
      variation_id: parseInt(btn.dataset.vid || "0", 10) || 0,
      name: btn.dataset.name || ""
    };
    adjustQuantity(ctx, delta, reason, "manual");
  }

  function adjustQuantity(ctx, delta, reason, source){
    if (!delta) return;
    var key = String(ctx.product_id) + ":" + String(ctx.variation_id) + ":" + String((ctx.sku||"").trim());
    markPending(key, true);
    optimisticAdjust(key, delta);

    api("/stock/adjust", {
      method: "POST",
      body: {
        sku: ctx.sku || "",
        product_id: ctx.product_id || 0,
        variation_id: ctx.variation_id || 0,
        delta: delta,
        reason: reason,
        source: source
      }
    }).then(function(data){
      markPending(key, false);
      if (data && typeof data.new_qty === "number") optimisticSet(key, data.new_qty);
      state.lastAction = { ctx: ctx, prev: data.old_qty, next: data.new_qty };
      toast("Updated.", "Undo", function(){ undoLast(); });
      fetchAudit(1,false,true);
    }).catch(function(e){
      if (shouldQueue(e)) {
        state.queue.push({ type:"adjust", payload:{ sku:ctx.sku, product_id:ctx.product_id, variation_id:ctx.variation_id, delta:delta, reason:reason, source:source }, key:key, ts:Date.now() });
        saveQueue();
        markPending(key, false);
        toast("Queued (offline / rate-limited). Tap Sync.");
      } else {
        // rollback
        optimisticAdjust(key, -delta);
        markPending(key, false);
        toast(e.message || "Update failed.");
      }
    });
  }

  function setQuantity(ctx, qty, reason, source){
    var key = String(ctx.product_id) + ":" + String(ctx.variation_id) + ":" + String((ctx.sku||"").trim());
    markPending(key, true);
    optimisticSet(key, qty);

    api("/stock/set", {
      method: "POST",
      body: {
        sku: ctx.sku || "",
        product_id: ctx.product_id || 0,
        variation_id: ctx.variation_id || 0,
        quantity: qty,
        reason: reason,
        source: source
      }
    }).then(function(data){
      markPending(key, false);
      if (data && typeof data.new_qty === "number") optimisticSet(key, data.new_qty);
      state.lastAction = { ctx: ctx, prev: data.old_qty, next: data.new_qty };
      toast("Saved.", "Undo", function(){ undoLast(); });
      fetchAudit(1,false,true);
    }).catch(function(e){
      if (shouldQueue(e)) {
        state.queue.push({ type:"set", payload:{ sku:ctx.sku, product_id:ctx.product_id, variation_id:ctx.variation_id, quantity:qty, reason:reason, source:source }, key:key, ts:Date.now() });
        saveQueue();
        markPending(key, false);
        toast("Queued (offline / rate-limited). Tap Sync.");
      } else {
        markPending(key, false);
        toast(e.message || "Save failed.");
      }
    });
  }

  function undoLast(){
    var a = state.lastAction;
    if (!a) return;
    state.lastAction = null;
    setQuantity(a.ctx, parseInt(a.prev || 0, 10), "undo", "manual");
  }

  function syncQueue(){
    if (!state.queue.length) return;
    toast("Syncing queued actions…", null, null, 1600);

    var copy = state.queue.slice();
    state.queue = [];
    saveQueue();
    render();

    var i = 0;
    function step(){
      if (i >= copy.length) {
        state.pending = {};
        savePending();
        toast("Synced.");
        fetchInventory(1,false,true);
        fetchAudit(1,false,true);
        return;
      }
      var act = copy[i++];
      var p = act.payload;
      var path = (act.type === "adjust") ? "/stock/adjust" : "/stock/set";
      api(path, { method:"POST", body: p }).then(function(){
        window.setTimeout(step, 120);
      }).catch(function(e){
        // re-queue remaining
        var remaining = copy.slice(i-1);
        state.queue = remaining.concat(state.queue);
        saveQueue();
        toast("Sync stopped: " + (e.message || "error"));
        render();
      });
    }
    step();
  }

  // Scanner
  function applyScanCode(codeOverride){
    var code = String(codeOverride != null ? codeOverride : ($("#vh-scan-code").value || "")).trim();
    if (!code) { toast("Enter a code."); return; }
    $("#vh-last-scan").textContent = code;
    state.lastScan = code;

    api("/barcode/resolve", { method:"GET", params:{ code: code } }).then(function(res){
      var ctx = {
        sku: res.sku || code,
        product_id: parseInt(res.product_id || 0, 10) || 0,
        variation_id: parseInt(res.variation_id || 0, 10) || 0,
        name: res.name || ""
      };
      var delta = (state.scanMode === "sale") ? -1 : +1;
      var reason = (state.scanMode === "sale") ? "sale" : "restock";
      adjustQuantity(ctx, delta, reason, "scan");
      $("#vh-scan-code").value = "";
      $("#vh-scan-code").focus();
      try { if (navigator.vibrate) navigator.vibrate(35); } catch(e){}
    }).catch(function(e){
      toast(e.message || "Not found.");
    });
  }

  function startCamera(){
    var video = $("#vh-video");
    if (!video) return;

    if (!window.isSecureContext) {
      toast("Camera needs HTTPS. Use manual code input.");
      return;
    }

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      toast("Camera not supported.");
      return;
    }

    if (state.camStream) return;

    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" } }, audio: false })
      .then(function(stream){
        state.camStream = stream;
        video.srcObject = stream;
        return video.play();
      })
      .then(function(){
        toast("Camera started.");
        startDetectLoop(video);
      })
      .catch(function(){
        toast("Camera blocked/unavailable.");
      });
  }

  function stopCamera(){
    var video = $("#vh-video");
    if (video) video.pause();
    if (state.camStream) {
      state.camStream.getTracks().forEach(function(t){ t.stop(); });
      state.camStream = null;
    }
    state.scanning = false;
  }

  function startDetectLoop(video){
    if (!("BarcodeDetector" in window)) {
      return;
    }
    var detector = null;
    try {
      window.BarcodeDetector.getSupportedFormats().then(function(formats){
        detector = new window.BarcodeDetector({ formats: formats });
        runLoop();
      }).catch(function(){
        detector = new window.BarcodeDetector();
        runLoop();
      });
    } catch(e){
      return;
    }

    function runLoop(){
      state.scanning = true;
      function loop(){
        if (!state.scanning || !state.camStream) return;
        detector.detect(video).then(function(barcodes){
          if (barcodes && barcodes.length) {
            var raw = String(barcodes[0].rawValue || "").trim();
            if (raw && raw !== state.lastScan) {
              state.lastScan = raw;
              $("#vh-scan-code").value = raw;
              applyScanCode(raw);
            }
          }
          window.requestAnimationFrame(loop);
        }).catch(function(){
          window.requestAnimationFrame(loop);
        });
      }
      window.requestAnimationFrame(loop);
    }
  }

  // Render
  function filteredSortedItems(){
    var low = parseInt(cfg.low || 5, 10);
    var s = String(state.search || "").trim().toLowerCase();
    var list = (state.items || []).slice();

    list = list.map(function(it){
      var k = keyOf(it);
      it._pending = !!state.pending[k];
      return it;
    });

    if (s) {
      list = list.filter(function(it){
        var sku = String(it.sku || "").toLowerCase();
        var name = String(it.name || "").toLowerCase();
        return sku.indexOf(s) >= 0 || name.indexOf(s) >= 0;
      });
    }

    if (state.filter === "low") list = list.filter(function(it){ return (typeof it.stock_qty === "number") && it.stock_qty < low; });
    if (state.filter === "out") list = list.filter(function(it){ return it.stock_qty === 0; });
    if (state.filter === "in")  list = list.filter(function(it){ return (typeof it.stock_qty === "number") && it.stock_qty > 0; });

    var dir = (state.sortDir === "desc") ? -1 : 1;
    list.sort(function(a,b){
      var sa = (state.sort === "stock") ? (a.stock_qty != null ? a.stock_qty : -999999) : (state.sort === "name" ? String(a.name||"") : String(a.sku||""));
      var sb = (state.sort === "stock") ? (b.stock_qty != null ? b.stock_qty : -999999) : (state.sort === "name" ? String(b.name||"") : String(b.sku||""));
      if (sa < sb) return -1*dir;
      if (sa > sb) return  1*dir;
      return 0;
    });

    return list;
  }

  function skeletonCard(){
    return '<div class="vh-skel"><div class="bar sm"></div><div class="bar md"></div><div class="bar lg"></div></div>';
  }

  function cardHtml(it){
    var low = parseInt(cfg.low || 5, 10);
    var sku = String(it.sku || "").trim();
    var hasSku = sku !== "";
    var qtyVal = (it.stock_qty == null) ? "—" : String(it.stock_qty);
    var qtyNum = (typeof it.stock_qty === "number") ? it.stock_qty : null;

    var qtyClass = "";
    if (it._pending) qtyClass = "pending";
    else if (qtyNum === 0) qtyClass = "zero";
    else if (qtyNum != null && qtyNum < low) qtyClass = "low";

    var metaParts = [];
    if (it.type) metaParts.push(esc(it.type));
    if (it.managing_stock === false && qtyNum === null) metaParts.push("Stock: not managed");
    if (it.variation_id) metaParts.push("Variation");

    var meta = metaParts.length ? '<div class="vh-meta">' + metaParts.map(function(m){ return '<span class="vh-pill">' + m + '</span>'; }).join("") + '</div>' : "";

    return ''
      + '<div class="vh-card" data-key="' + esc(keyOf(it)) + '">'
      + '  <div class="vh-row">'
      + '    <div class="vh-left">'
      + '      <div class="vh-sku">' + (hasSku ? esc(sku) : 'NO SKU') + '</div>'
      + '      <div class="vh-name" title="' + esc(it.name || "") + '">' + esc(it.name || "") + '</div>'
      +        meta
      + '    </div>'
      + '    <div class="vh-right">'
      + '      <div class="vh-price">' + (it.price == null ? '—' : (typeof Intl !== "undefined" ? new Intl.NumberFormat(undefined, { style:"currency", currency:"INR" }).format(Number(it.price)) : String(it.price))) + '</div>'
      + '      <div class="vh-qty ' + qtyClass + '">' + esc(qtyVal) + '</div>'
      + '    </div>'
      + '  </div>'
      + '  <div class="vh-btnrow">'
      + '    <button class="vh-btn vh-btn-dec" data-sku="' + esc(sku) + '" data-pid="' + String(it.product_id||0) + '" data-vid="' + String(it.variation_id||0) + '" data-name="' + esc(it.name||"") + '" title="Sale (-1)">' + icon.minus + ' Sale</button>'
      + '    <button class="vh-btn vh-btn-inc" data-sku="' + esc(sku) + '" data-pid="' + String(it.product_id||0) + '" data-vid="' + String(it.variation_id||0) + '" data-name="' + esc(it.name||"") + '" title="Restock (+1)">' + icon.plus + ' Restock</button>'
      + '    <button class="vh-btn vh-btn-set primary" data-sku="' + esc(sku) + '" data-pid="' + String(it.product_id||0) + '" data-vid="' + String(it.variation_id||0) + '" data-name="' + esc(it.name||"") + '" data-qty="' + esc(qtyVal) + '" title="Set quantity">' + icon.set + ' Set</button>'
      + '  </div>'
      + '</div>';
  }

  function auditHtml(r){
    var d = parseInt(r.delta || 0, 10) || 0;
    var cls = (d >= 0) ? "pos" : "neg";
    var deltaText = (d >= 0) ? ("+" + d) : String(d);
    return ''
      + '<div class="vh-audititem">'
      + '  <div class="top">'
      + '    <div class="sku">' + esc(r.sku || "—") + '</div>'
      + '    <div class="delta ' + cls + '">' + esc(deltaText) + '</div>'
      + '  </div>'
      + '  <div class="meta">' + esc(r.reason || "manual") + ' • New: ' + esc(r.new_qty == null ? "—" : r.new_qty) + ' • ' + esc(r.source || "manual") + '</div>'
      + '  <div class="time">' + esc(r.created_at || "") + '</div>'
      + '</div>';
  }

  function renderInventory(){
    var view = $("#vh-view");
    var list = filteredSortedItems();

    if (state.loadingInv && (!state.items || !state.items.length)) {
      view.innerHTML = '<div class="vh-list">' + skeletonCard() + skeletonCard() + skeletonCard() + '</div>';
      return;
    }
    if (!list.length) {
      view.innerHTML = '<div class="vh-empty">No products found.</div>';
      return;
    }

    view.innerHTML = '<div class="vh-list">'
      + list.map(cardHtml).join("")
      + ((state.invPage < state.invPages) ? '<div class="vh-card"><button class="vh-btn primary" id="vh-load-more">Load more</button></div>' : '')
      + '</div>';

    $$(".vh-btn-dec", view).forEach(function(btn){ btn.addEventListener("click", function(){ adjust(btn, -1, "sale"); }); });
    $$(".vh-btn-inc", view).forEach(function(btn){ btn.addEventListener("click", function(){ adjust(btn, +1, "restock"); }); });
    $$(".vh-btn-set", view).forEach(function(btn){ btn.addEventListener("click", function(){ openSet(btn); }); });

    var more = $("#vh-load-more", view);
    if (more) more.addEventListener("click", function(){ fetchInventory(state.invPage + 1, true, false); });
  }

  function renderAudit(){
    var view = $("#vh-view");

    if (state.loadingAudit && (!state.audit || !state.audit.length)) {
      view.innerHTML = '<div class="vh-list">' + skeletonCard() + skeletonCard() + '</div>';
      return;
    }
    if (!state.audit || !state.audit.length) {
      view.innerHTML = '<div class="vh-empty">No audit entries yet.</div>';
      return;
    }

    view.innerHTML = ''
      + '<div class="vh-card"><div class="vh-row">'
      + '  <div class="vh-left"><div class="vh-name">Audit trail</div><div class="vh-meta"><span class="vh-pill">Export is CSV</span></div></div>'
      + '  <div class="vh-right"><button class="vh-btn" id="vh-export">' + icon.export + ' Export</button></div>'
      + '</div></div>'
      + '<div class="vh-list">'
      + state.audit.map(auditHtml).join("")
      + ((state.auditPage < state.auditPages) ? '<div class="vh-card"><button class="vh-btn primary" id="vh-audit-more">Load more</button></div>' : '')
      + '</div>';

    $("#vh-export").addEventListener("click", function(){
      var url = new URL(cfg.exportUrl, window.location.origin);
      url.searchParams.set("_wpnonce", cfg.exportNonce);
      url.searchParams.set("limit", "5000");
      window.location.href = url.toString();
    });
    var more = $("#vh-audit-more");
    if (more) more.addEventListener("click", function(){ fetchAudit(state.auditPage + 1, true, false); });
  }

  function render(){
    $("#vh-tab-inv").setAttribute("aria-selected", (state.tab === "inv") ? "true" : "false");
    $("#vh-tab-audit").setAttribute("aria-selected", (state.tab === "audit") ? "true" : "false");

    var q = state.queue.length;
    $("#vh-qbadge").textContent = String(q);
    $("#vh-sync").style.display = (q > 0) ? "inline-flex" : "none";

    if (state.tab === "inv") renderInventory();
    else renderAudit();
  }

  function fetchInventory(page, append, quiet){
    page = page || 1;
    append = !!append;
    quiet = !!quiet;
    if (state.loadingInv) return;
    state.loadingInv = true;
    if (!quiet) render();

    api("/inventory", { method:"GET", params:{ page: page } }).then(function(data){
      state.invPage = parseInt(data.page || page, 10) || page;
      state.invPages = parseInt(data.pages || 1, 10) || 1;
      var items = (data.items && data.items.length) ? data.items : [];
      state.items = append ? state.items.concat(items) : items;
    }).catch(function(e){
      if (!quiet) toast(e.message || "Failed to load inventory.");
    }).finally(function(){
      state.loadingInv = false;
      render();
    });
  }

  function fetchAudit(page, append, quiet){
    page = page || 1;
    append = !!append;
    quiet = !!quiet;
    if (state.loadingAudit) return;
    state.loadingAudit = true;
    if (!quiet) render();

    api("/audit", { method:"GET", params:{ page: page } }).then(function(data){
      state.auditPage = parseInt(data.page || page, 10) || page;
      state.auditPages = parseInt(data.pages || 1, 10) || 1;
      var rows = (data.rows && data.rows.length) ? data.rows : [];
      state.audit = append ? state.audit.concat(rows) : rows;
    }).catch(function(e){
      if (!quiet) toast(e.message || "Failed to load audit.");
    }).finally(function(){
      state.loadingAudit = false;
      render();
    });
  }

  // Boot
  render();
  fetchInventory(1,false,true);
})();
